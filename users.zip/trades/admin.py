from django.contrib import admin
from .models import Trade

# Register your models here.
admin.site.register(Trade)